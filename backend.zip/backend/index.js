const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

// ---- In-memory state (no database, no localStorage) ----
const onlineUsers = new Map(); // socket.id -> username
const messageHistory = []; // capped array of recent messages
const MAX_HISTORY = 200;

function getOnlineUsernames() {
  return Array.from(onlineUsers.values());
}

function sanitizeName(name) {
  return String(name || '').trim().slice(0, 30);
}

function sanitizeText(text) {
  return String(text || '').trim().slice(0, 2000);
}

io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);

  socket.on('join', (rawUsername, callback) => {
    const username = sanitizeName(rawUsername);

    if (!username) {
      if (typeof callback === 'function') {
        callback({ ok: false, error: 'Name is required.' });
      }
      return;
    }

    onlineUsers.set(socket.id, username);
    socket.data.username = username;

    // Send the joining client its own info + current history + online list
    if (typeof callback === 'function') {
      callback({
        ok: true,
        username,
        history: messageHistory,
        onlineUsers: getOnlineUsernames(),
        onlineCount: onlineUsers.size,
      });
    }

    // Let everyone else know someone joined
    socket.broadcast.emit('user-joined', {
      username,
      onlineUsers: getOnlineUsernames(),
      onlineCount: onlineUsers.size,
    });
  });

  socket.on('chat message', (rawText, callback) => {
    const username = socket.data.username;
    const text = sanitizeText(rawText);

    if (!username) {
      if (typeof callback === 'function') {
        callback({ ok: false, error: 'You must join before sending messages.' });
      }
      return;
    }

    if (!text) {
      if (typeof callback === 'function') {
        callback({ ok: false, error: 'Message cannot be empty.' });
      }
      return;
    }

    const message = {
      id: `${socket.id}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      username,
      text,
      timestamp: Date.now(),
    };

    messageHistory.push(message);
    if (messageHistory.length > MAX_HISTORY) {
      messageHistory.shift();
    }

    io.emit('chat message', message);

    if (typeof callback === 'function') {
      callback({ ok: true, message });
    }
  });

  socket.on('typing', () => {
    const username = socket.data.username;
    if (!username) return;
    socket.broadcast.emit('typing', { username });
  });

  socket.on('stop typing', () => {
    const username = socket.data.username;
    if (!username) return;
    socket.broadcast.emit('stop typing', { username });
  });

  socket.on('disconnect', () => {
    const username = onlineUsers.get(socket.id);
    onlineUsers.delete(socket.id);

    if (username) {
      socket.broadcast.emit('user-left', {
        username,
        onlineUsers: getOnlineUsernames(),
        onlineCount: onlineUsers.size,
      });
    }

    console.log(`Client disconnected: ${socket.id}`);
  });
});

app.get('/', (req, res) => {
  res.send('Server is running');
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', onlineCount: onlineUsers.size });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
